/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escuela;

/**
 *
 * @author JOVANNI SG
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.mycompany.escuela.Escuelas;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class GrupoDAO {
    public void guardarGrupo(Grupo grupo) throws SQLException {
       String sql = "INSERT INTO Grupo (grado, grupo, turno, escuela_nombre, nombreMateria, añoDeInicio) VALUES (?, ?, ?, ?, ?, ?)";
try (Connection conn = DatabaseConnection.getConnection();
     PreparedStatement stmt = conn.prepareStatement(sql)) {
    stmt.setString(1, grupo.getGrado());
    stmt.setString(2, grupo.getGrupo());
    stmt.setString(3, grupo.getTurno());
    stmt.setString(4, grupo.getEscuela_nombre());  // Cambié "escuelaNombre" a "escuela_nombre"
    stmt.setString(5, grupo.getNombreMateria());
    stmt.setString(6, grupo.getAñoDeInicio());
    stmt.executeUpdate();
    System.out.println("Grupo guardado exitosamente");
} catch (SQLException e) {
    System.err.println("Error al guardar el grupo: " + e.getMessage());
    throw e;
}

    }
   //Metodo que muestra los grupos de una escuela y que estan activos.
   public List<String> obtenerDetallesGruposPorEscuela(String escuelaNombre) throws SQLException {
    List<String> detallesGrupos = new ArrayList<>();
    String sql = "SELECT idGrupo, grado, grupo, turno, nombreMateria, añoDeInicio " +
                 "FROM Grupo WHERE escuela_nombre = ? AND activo = TRUE"; // Filtra solo los activos

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, escuelaNombre);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            // Crear el detalle incluyendo el idGrupo
            String detalle = "ID: " + rs.getInt("idGrupo") + 
                             " | Grupo: " + rs.getString("grado") +
                             "-" + rs.getString("grupo") +
                             " | Turno: " + rs.getString("turno") +
                             " | Materia: " + rs.getString("nombreMateria") +
                             " | Año: " + rs.getString("añoDeInicio");
            detallesGrupos.add(detalle);
        }
    }
    return detallesGrupos;
}
    // Método para eliminar un grupo
    public void eliminarGrupo(int idGrupo) throws SQLException {
    String sql = "DELETE FROM Grupo WHERE idgrupo = ?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idGrupo);
        int rowsAffected = stmt.executeUpdate();
        
        if (rowsAffected > 0) {
            System.out.println("Grupo eliminado exitosamente");
        } else {
            System.out.println("No se encontró un grupo con el ID proporcionado.");
        }
    } catch (SQLException e) {
        System.err.println("Error al eliminar el grupo: " + e.getMessage());
        throw e;
    }
}
    public boolean existeGrupo(int idGrupo) throws SQLException {
    String sql = "SELECT COUNT(*) FROM Grupo WHERE idgrupo = ?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idGrupo);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return rs.getInt(1) > 0;  // Si el conteo es mayor que 0, significa que el grupo existe
        }
    }
    return false;  // Si no se encuentra el grupo
}
// Método para obtener todos los grupos con sus detalles y estado
public List<String> obtenerTodosLosGrupos() throws SQLException {
    List<String> detallesGrupos = new ArrayList<>();
    String sql = "SELECT idGrupo, grado, grupo, turno, escuela_nombre, nombreMateria, añoDeInicio, activo FROM Grupo";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            // Evaluar el estado del grupo
            boolean estadoActivo = rs.getBoolean("activo");
            String estadoTexto = estadoActivo ? "Activo" : "Desactivado";

            // Formatear cada detalle de grupo
            String detalle = "ID: " + rs.getInt("idGrupo") +
                             " | Grado: " + rs.getString("grado") +
                             "-" + rs.getString("grupo") +
                             " | Turno: " + rs.getString("turno") +
                             " | Escuela: " + rs.getString("escuela_nombre") +
                             " | Materia: " + rs.getString("nombreMateria") +
                             " | Año: " + rs.getString("añoDeInicio") +
                             " | Estado: " + estadoTexto;

            detallesGrupos.add(detalle);
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener los grupos: " + e.getMessage());
        throw e;
    }

    return detallesGrupos;
}
//Metodo Activados
public List<String> obtenerGruposActivos() throws SQLException {
    List<String> detallesGrupos = new ArrayList<>();
    String sql = "SELECT idGrupo, grado, grupo, turno, escuela_nombre, nombreMateria, añoDeInicio, activo FROM Grupo WHERE activo = true";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            String detalle = "ID: " + rs.getInt("idGrupo") +
                             " | Grado: " + rs.getString("grado") +
                             "-" + rs.getString("grupo") +
                             " | Turno: " + rs.getString("turno") +
                             " | Escuela: " + rs.getString("escuela_nombre") +
                             " | Materia: " + rs.getString("nombreMateria") +
                             " | Año: " + rs.getString("añoDeInicio") +
                             " | Estado: Activo";

            detallesGrupos.add(detalle);
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener los grupos activos: " + e.getMessage());
        throw e;
    }

    return detallesGrupos;
}
//Metodos Lista Desactivados
public List<String> obtenerGruposDesactivados() throws SQLException {
    List<String> detallesGrupos = new ArrayList<>();
    String sql = "SELECT idGrupo, grado, grupo, turno, escuela_nombre, nombreMateria, añoDeInicio, activo FROM Grupo WHERE activo = false";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            String detalle = "ID: " + rs.getInt("idGrupo") +
                             " | Grado: " + rs.getString("grado") +
                             "-" + rs.getString("grupo") +
                             " | Turno: " + rs.getString("turno") +
                             " | Escuela: " + rs.getString("escuela_nombre") +
                             " | Materia: " + rs.getString("nombreMateria") +
                             " | Año: " + rs.getString("añoDeInicio") +
                             " | Estado: Desactivado";

            detallesGrupos.add(detalle);
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener los grupos desactivados: " + e.getMessage());
        throw e;
    }

    return detallesGrupos;
}

// Método para actualizar el estado 'activo' de un grupo dado su idGrupo
public void actualizarEstadoActivo(int idGrupo, boolean nuevoEstado) throws SQLException {
    String sql = "UPDATE Grupo SET activo = ? WHERE idGrupo = ?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setBoolean(1, nuevoEstado); // true o false según lo que pases
        stmt.setInt(2, idGrupo);

        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Estado actualizado exitosamente para el grupo con ID: " + idGrupo);
        } else {
            System.out.println("No se encontró un grupo con el ID proporcionado.");
        }
    } catch (SQLException e) {
        System.err.println("Error al actualizar el estado del grupo: " + e.getMessage());
        throw e;
    }
}

public void actualizarEstado(int idGrupo, boolean activo) throws SQLException {
    String sql = "UPDATE Grupo SET activo = ? WHERE idGrupo = ?";
    try (Connection conn = conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setBoolean(1, activo);
        stmt.setInt(2, idGrupo);
        stmt.executeUpdate();
    }
}

    private Connection conectar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
