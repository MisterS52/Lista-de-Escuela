/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.escuela;

import Interfas.PantallaDeIncio;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author JOVANNI SG
 */
public class ESCUELA {
    public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
        try {
            // Intentar conectar a la base de datos "Escuela"
            Connection connection = DatabaseConnection.getConnection();
            System.out.println("Conexion exitosa a la base de datos 'Escuela'");

            // Inicializar la pantalla de inicio
            PantallaDeIncio pantalla = new PantallaDeIncio();
            pantalla.setVisible(true);
            pantalla.setLocationRelativeTo(null);

        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            // Crear estructura de tablas si no existen
            Connection connection = DatabaseConnection.getConnection();
            crearEstructuraBaseDatos(connection);
        }
    }

    private static void crearEstructuraBaseDatos(Connection connection) {
        try (Statement stmt = connection.createStatement()) {
            // Crear tablas si no existen
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS Escuela(
                    nombre VARCHAR(150) PRIMARY KEY,
                    direccion VARCHAR(150),
                    clave VARCHAR(30),
                    TipoEscuela VARCHAR(255)
                );
                
                CREATE TABLE IF NOT EXISTS Grupo(
                    idgrupo SERIAL PRIMARY KEY,
                    grado VARCHAR(2),
                    grupo VARCHAR(2),
                    turno VARCHAR(12),
                    escuela_nombre VARCHAR(150),
                    NombreMateria VARCHAR(255),
                    AñoDeInicio VARCHAR(255),
                    activo BOOLEAN DEFAULT TRUE,
                    FOREIGN KEY (escuela_nombre) REFERENCES Escuela(nombre)
                );
                
                CREATE TABLE IF NOT EXISTS Alumno(
                    idAlumno SERIAL PRIMARY KEY,
                    nombre VARCHAR(150),
                    apellido_paterno VARCHAR(150),
                    apellido_materno VARCHAR(150),
                    id_grupo INTEGER,
                    Promedio DECIMAL(5,2),
                    PorcentajeAsistencia DECIMAL(5,2) DEFAULT 0,
                    FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo)
                );
                
                CREATE TABLE IF NOT EXISTS Fechas_asistencia(
                    idFecha SERIAL PRIMARY KEY,
                    fecha DATE,
                    id_grupo INTEGER,
                    FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo)
                );
                
                CREATE TABLE IF NOT EXISTS Actividad(
                    idActividad SERIAL PRIMARY KEY,
                    fecha DATE,
                    id_grupo INTEGER,
                    NombreActividad VARCHAR(255),
                    FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo)
                );
                
                CREATE TABLE IF NOT EXISTS Asistencia(
                    idAsistencia SERIAL PRIMARY KEY,
                    idFecha INTEGER,
                    idAlumno INTEGER,
                    asistencia INTEGER,
                    no_Duplicado TEXT GENERATED ALWAYS AS (idFecha || '-' || idAlumno) STORED,
                    FOREIGN KEY (idFecha) REFERENCES Fechas_asistencia(idFecha),
                    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
                    CONSTRAINT unique_no_duplicado UNIQUE (no_Duplicado)
                );
                
                CREATE TABLE IF NOT EXISTS Evaluacion(
                    idEvaluacion SERIAL PRIMARY KEY,
                    idAlumno INTEGER,
                    idActividad INTEGER,
                    calificacion INTEGER,
                    no_Duplicado TEXT GENERATED ALWAYS AS (idActividad || '-' || idAlumno) STORED,
                    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
                    FOREIGN KEY (idActividad) REFERENCES Actividad(idActividad),
                    CONSTRAINT unique_no_duplicados UNIQUE (no_Duplicado)
                );
            """);

            System.out.println("✅ Tablas creadas correctamente.");

            // Crear triggers para actualizar Promedio y PorcentajeAsistencia automáticamente
            crearTriggers(connection);

        } catch (SQLException e) {
            System.err.println("❌ Error al crear las tablas: " + e.getMessage());
        }
    }

    private static void crearTriggers(Connection connection) {
        try (Statement stmt = connection.createStatement()) {
            // Trigger para actualizar el promedio del alumno
            stmt.executeUpdate("""
                CREATE OR REPLACE FUNCTION actualizar_promedio()
                RETURNS TRIGGER AS $$
                BEGIN
                    UPDATE Alumno
                    SET Promedio = (
                        SELECT COALESCE(AVG(calificacion), 0)
                        FROM Evaluacion
                        WHERE idAlumno = NEW.idAlumno
                    )
                    WHERE idAlumno = NEW.idAlumno;
                    
                    RETURN NEW;
                END;
                $$ LANGUAGE plpgsql;
                
                DROP TRIGGER IF EXISTS trigger_actualizar_promedio ON Evaluacion;
                CREATE TRIGGER trigger_actualizar_promedio
                AFTER INSERT OR UPDATE OR DELETE ON Evaluacion
                FOR EACH ROW EXECUTE FUNCTION actualizar_promedio();
            """);

            // Trigger para actualizar el porcentaje de asistencia del alumno
            stmt.executeUpdate("""
                CREATE OR REPLACE FUNCTION actualizar_porcentaje_asistencia()
                RETURNS TRIGGER AS $$
                DECLARE
                    total_asistencias INTEGER;
                    total_registros INTEGER;
                    porcentaje DECIMAL(5,2);
                BEGIN
                    SELECT COUNT(*) INTO total_asistencias
                    FROM Asistencia
                    WHERE idAlumno = NEW.idAlumno AND asistencia = 1;
                    
                    SELECT COUNT(*) INTO total_registros
                    FROM Asistencia
                    WHERE idAlumno = NEW.idAlumno;
                    
                    IF total_registros > 0 THEN
                        porcentaje := (total_asistencias * 100.0) / total_registros;
                    ELSE
                        porcentaje := 0;
                    END IF;
                    
                    UPDATE Alumno
                    SET PorcentajeAsistencia = porcentaje
                    WHERE idAlumno = NEW.idAlumno;
                    
                    RETURN NEW;
                END;
                $$ LANGUAGE plpgsql;
                
                DROP TRIGGER IF EXISTS trigger_actualizar_asistencia ON Asistencia;
                CREATE TRIGGER trigger_actualizar_asistencia
                AFTER INSERT OR UPDATE OR DELETE ON Asistencia
                FOR EACH ROW EXECUTE FUNCTION actualizar_porcentaje_asistencia();
            """);

            System.out.println("✅ Triggers creados correctamente.");

        } catch (SQLException e) {
            System.err.println("❌ Error al crear los triggers: " + e.getMessage());
        }
    }
}