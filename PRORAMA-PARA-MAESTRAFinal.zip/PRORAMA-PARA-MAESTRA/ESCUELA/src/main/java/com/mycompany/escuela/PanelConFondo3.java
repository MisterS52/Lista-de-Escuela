/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escuela;

import javax.swing.*;
import java.awt.*;

public class PanelConFondo3 extends JPanel {
    private Image imagen;

    public PanelConFondo3() {
        ImageIcon icon = new ImageIcon("src/main/java/Imagenes/naranja.jpeg");
        imagen = icon.getImage();
        setOpaque(false); // Importante para que los componentes se vean sobre la imagen
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
