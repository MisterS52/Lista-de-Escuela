/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escuela;

import javax.swing.*;
import java.awt.*;

public class Imagenes extends JPanel {
    private Image imagen;

    public Imagenes() {
        // Carga desde ruta directa (solo en desarrollo)
        ImageIcon icon = new ImageIcon("src/main/java/Imagenes/Pagina1.png");
        this.imagen = icon.getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}

