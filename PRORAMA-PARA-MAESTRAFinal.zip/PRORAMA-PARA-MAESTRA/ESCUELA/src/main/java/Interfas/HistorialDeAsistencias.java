/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfas;
import com.mycompany.escuela.AsistenciaDAO;
import com.mycompany.escuela.AsistenciaDAO.AsistenciaInfo;
import com.mycompany.escuela.GrupoDAO;
import com.mycompany.escuela.AlumnoDAO;
import com.mycompany.escuela.EscuelaDAO;
import com.mycompany.escuela.PanelConFondo3;
import java.sql.SQLException;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author JOVANNI SG
 */
public class HistorialDeAsistencias extends javax.swing.JFrame {

    /**
     * Creates new form HistorialDeAsistencias
     */
    private int idGrupo;
    Clase pantallaPrincipale; // Referencia a la Pantalla principal
    private EscuelaDAO escuelaDAO; 
    private GrupoDAO grupoDAO;
    private AlumnoDAO alumnoDAO;
    public HistorialDeAsistencias(int idGrupo,Clase pantallas,AlumnoDAO alumnoDAO) {
        this.idGrupo = idGrupo;
        this.alumnoDAO = alumnoDAO; // Inicializamos alumnoDAO
        this.pantallaPrincipale = pantallas; // Se pasa la referencia a Pantalla principal
        initComponents();
        cargarHistorial();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // o HIDE_ON_CLOSE según lo que necesites
        cargarAlumnosPorGrupo();
        setTitle("NuevaEscuela");
         // Agregar el ListSelectionListener después de initComponents()
    ListadeAlumnos.addListSelectionListener(event -> {
        if (!event.getValueIsAdjusting()) {
            actualizarPorcentajeAsistencia();
        }
    });
    }
    
    private void cargarAlumnosPorGrupo() {
  
    try {
        System.out.println("Cargando alumnos para el grupo con ID: " + idGrupo);
        
        // Obtener los detalles de los alumnos para el grupo seleccionado
        List<String> detallesAlumnos = alumnoDAO.obtenerDetallesAlumnosPorGrupo(idGrupo);
        
        System.out.println("Alumnos obtenidos: " + detallesAlumnos);

        // Crear un modelo para la lista de alumnos
        DefaultListModel<String> model = new DefaultListModel<>();

        // Agregar cada detalle de alumno al modelo
        for (String detalle : detallesAlumnos) {
            model.addElement(detalle); // Añadir el detalle a la lista
        }

        // Asignar el modelo a la JList
        ListadeAlumnos.setModel(model);
        System.out.println("Modelo actualizado con " + model.getSize() + " alumnos.");

    } catch (SQLException e) {
        e.printStackTrace(); // Mostrar detalles del error en la consola
        JOptionPane.showMessageDialog(this, "Error al cargar los alumnos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    private void cargarHistorial() {
        try {
            AsistenciaDAO asistenciaDAO = new AsistenciaDAO();
            List<AsistenciaInfo> asistencias = asistenciaDAO.obtenerAsistenciasPorGrupo(idGrupo);

            StringBuilder historialTexto = new StringBuilder();
            for (AsistenciaInfo info : asistencias) {
                historialTexto.append(info.toString()).append("\n");
            }

            jTextArea1.setText(historialTexto.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar el historial de asistencias: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new PanelConFondo3();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ListadeAlumnos = new javax.swing.JList<>();
        jLabel4 = new javax.swing.JLabel();
        porsentaje = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabel1.setText("Historial de Asistencia");

        jTextArea1.setBackground(new java.awt.Color(255, 204, 51));
        jTextArea1.setColumns(20);
        jTextArea1.setForeground(new java.awt.Color(153, 153, 153));
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel2.setText("Historial de Asistencia por Alumno:");

        ListadeAlumnos.setBackground(new java.awt.Color(255, 204, 51));
        ListadeAlumnos.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        ListadeAlumnos.setForeground(new java.awt.Color(153, 153, 153));
        jScrollPane2.setViewportView(ListadeAlumnos);

        jLabel4.setText("Porsentaje de Asistencia:");

        porsentaje.setText("0");
        porsentaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                porsentajeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(205, 205, 205)
                            .addComponent(jLabel1))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(19, 19, 19)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(9, 9, 9)
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(porsentaje, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(porsentaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void porsentajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_porsentajeActionPerformed
      String seleccion = ListadeAlumnos.getSelectedValue(); // Obtener el texto seleccionado
    if (seleccion != null) {
        try {
            // Extraer el ID del alumno de la selección (suponiendo que el formato es "ID: 5 | Nombre: Juan Pérez")
            String[] partes = seleccion.split("\\|"); 
            if (partes.length > 0) {
                String idTexto = partes[0].replace("ID:", "").trim(); // Extraer el número de ID
                int idAlumno = Integer.parseInt(idTexto); // Convertir a entero
                
                // Obtener porcentaje de asistencia
                double asistencia = alumnoDAO.obtenerPorcentajeAsistencia(idAlumno);
                
                // Mostrar en el campo de texto
                porsentaje.setText(String.valueOf(asistencia));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener la asistencia: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error al procesar el ID del alumno.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_porsentajeActionPerformed

    private void actualizarPorcentajeAsistencia() {
    String seleccion = ListadeAlumnos.getSelectedValue(); // Obtener el texto seleccionado
    if (seleccion != null) {
        try {
            // Extraer el ID del alumno de la selección
            String[] partes = seleccion.split("\\|"); 
            if (partes.length > 0) {
                String idTexto = partes[0].replace("ID:", "").trim(); // Obtener ID
                int idAlumno = Integer.parseInt(idTexto); // Convertir a entero
                
                // Obtener porcentaje de asistencia desde AlumnoDAO
                double asistencia = alumnoDAO.obtenerPorcentajeAsistencia(idAlumno);
                
                // Mostrar en el campo de texto
                porsentaje.setText(String.valueOf(asistencia));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener la asistencia: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error al procesar el ID del alumno.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ListadeAlumnos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField porsentaje;
    // End of variables declaration//GEN-END:variables
}
