package Interfas;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.Desktop;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.BaseColor;
import com.mycompany.escuela.DatabaseConnection;

public class EstadisticasGraficas extends JFrame {
    private JComboBox<String> comboGrupos;
    private JPanel panelGraficas;
    private Connection conn;
    private ChartPanel chartPanel;
    private JPanel panelDetalles;
    private int idGrupoActual = -1;
    private String nombreGrupo = "";
    private List<Object[]> datosAlumnos; // Para almacenar los datos y no tener que consultarlos de nuevo
    private enum TipoGrafica { BARRAS, PASTEL }
    private TipoGrafica tipoGraficaActual = TipoGrafica.BARRAS;
    private JButton btnTipoGrafica; // Para poder actualizar su texto

    // Constructor original sin parámetros (lo mantenemos para compatibilidad)
    public EstadisticasGraficas() {
        setTitle("Estadísticas Gráficas por Grupo");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        conectarBaseDatos();
        cargarGrupos();
    }
    
    // Nuevo constructor que recibe el ID del grupo y su nombre
    public EstadisticasGraficas(int idGrupo, String nombreGrupo) {
        this.idGrupoActual = idGrupo;
        this.nombreGrupo = nombreGrupo;
        setTitle("Estadísticas Gráficas - " + nombreGrupo);
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponentesSinCombobox(); // Nueva inicialización de componentes sin combobox
        conectarBaseDatos();
        // No llamamos a cargarGrupos() porque ya tenemos el grupo específico
        actualizarEstadisticasDirecto(idGrupo);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        
        // Panel superior para seleccionar grupo
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        comboGrupos = new JComboBox<>();
        panelSuperior.add(new JLabel("Seleccionar Grupo: "));
        panelSuperior.add(comboGrupos);
        add(panelSuperior, BorderLayout.NORTH);
        
        // Panel central para gráficas y detalles
        JPanel panelCentral = new JPanel(new BorderLayout());
        
        // Panel para la gráfica
        panelGraficas = new JPanel(new BorderLayout());
        panelGraficas.setBorder(BorderFactory.createTitledBorder("Estado del Grupo"));
        
        // Inicializar panel de gráfico vacío
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        JFreeChart chart = ChartFactory.createBarChart(
                "Estado del Grupo", 
                "Rango", 
                "Cantidad de Alumnos", 
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);
        
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        panelGraficas.add(chartPanel, BorderLayout.CENTER);
        
        // Panel para detalles (parte inferior)
        panelDetalles = new JPanel();
        panelDetalles.setLayout(new BoxLayout(panelDetalles, BoxLayout.Y_AXIS));
        panelDetalles.setBorder(BorderFactory.createTitledBorder("Información Adicional"));
        
        // Añadir ambos paneles al panel central
        panelCentral.add(panelGraficas, BorderLayout.CENTER);
        panelCentral.add(panelDetalles, BorderLayout.SOUTH);
        
        add(panelCentral, BorderLayout.CENTER);
        
        // Panel inferior con botones
        JPanel panelInferior = new JPanel();
        JButton btnActualizar = new JButton("Actualizar Estadísticas");
        btnActualizar.addActionListener(e -> actualizarEstadisticas());
        btnTipoGrafica = new JButton("Cambiar a Pastel");
        btnTipoGrafica.addActionListener(e -> cambiarTipoGrafica());
        JButton btnExportarPDF = new JButton("Exportar a PDF");
        btnExportarPDF.addActionListener(e -> exportarAPDF());
        panelInferior.add(btnActualizar);
        panelInferior.add(btnTipoGrafica);
        panelInferior.add(btnExportarPDF);
        add(panelInferior, BorderLayout.SOUTH);
        
        // Agregar listener al combo
        comboGrupos.addActionListener(e -> actualizarEstadisticas());
    }

    private void initComponentesSinCombobox() {
        setLayout(new BorderLayout(10, 10));
        
        // Panel superior para mostrar el grupo seleccionado (sólo texto)
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel labelGrupo = new JLabel("Grupo: " + nombreGrupo);
        labelGrupo.setFont(new Font("SansSerif", Font.BOLD, 14));
        panelSuperior.add(labelGrupo);
        add(panelSuperior, BorderLayout.NORTH);
        
        // Panel central para gráficas y detalles
        JPanel panelCentral = new JPanel(new BorderLayout());
        
        // Panel para la gráfica
        panelGraficas = new JPanel(new BorderLayout());
        panelGraficas.setBorder(BorderFactory.createTitledBorder("Estado del Grupo"));
        
        // Inicializar panel de gráfico vacío
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        JFreeChart chart = ChartFactory.createBarChart(
                "Estado del Grupo", 
                "Rango", 
                "Cantidad de Alumnos", 
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);
        
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        panelGraficas.add(chartPanel, BorderLayout.CENTER);
        
        // Panel para detalles (parte inferior)
        panelDetalles = new JPanel();
        panelDetalles.setLayout(new BoxLayout(panelDetalles, BoxLayout.Y_AXIS));
        panelDetalles.setBorder(BorderFactory.createTitledBorder("Información Adicional"));
        
        // Añadir ambos paneles al panel central
        panelCentral.add(panelGraficas, BorderLayout.CENTER);
        panelCentral.add(panelDetalles, BorderLayout.SOUTH);
        
        add(panelCentral, BorderLayout.CENTER);
        
        // Panel inferior con botones
        JPanel panelInferior = new JPanel();
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        btnTipoGrafica = new JButton("Cambiar a Pastel");
        btnTipoGrafica.addActionListener(e -> cambiarTipoGrafica());
        JButton btnExportarPDF = new JButton("Exportar a PDF");
        btnExportarPDF.addActionListener(e -> exportarAPDF());
        panelInferior.add(btnCerrar);
        panelInferior.add(btnTipoGrafica);
        panelInferior.add(btnExportarPDF);
        add(panelInferior, BorderLayout.SOUTH);
    }

   private void conectarBaseDatos() {
    try {
        conn = DatabaseConnection.getConnection();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
    }
}

    private void cargarGrupos() {
        try {
            String query = "SELECT DISTINCT g.idgrupo, g.grado, g.grupo, g.turno, g.nombremateria " +
                          "FROM Grupo g WHERE g.activo = true " +
                          "ORDER BY g.grado, g.grupo";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            comboGrupos.removeAllItems();
            while (rs.next()) {
                String grupoInfo = String.format("%s°%s - %s - %s (ID: %d)", 
                    rs.getString("grado"),
                    rs.getString("grupo"),
                    rs.getString("turno"),
                    rs.getString("nombremateria"),
                    rs.getInt("idgrupo"));
                comboGrupos.addItem(grupoInfo);
            }
            
            // Seleccionar el primer elemento por defecto
            if (comboGrupos.getItemCount() > 0) {
                comboGrupos.setSelectedIndex(0);
                actualizarEstadisticas();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar grupos: " + e.getMessage());
        }
    }

    private int getSelectedGroupId() {
        if (comboGrupos.getSelectedItem() == null) return -1;
        
        String seleccion = comboGrupos.getSelectedItem().toString();
        return Integer.parseInt(seleccion.substring(seleccion.lastIndexOf("ID: ") + 4, seleccion.length() - 1));
    }

    private void actualizarEstadisticas() {
        int idGrupo = getSelectedGroupId();
        if (idGrupo == -1) return;

        // Obtener los datos
        List<Object[]> detallesAlumnos = cargarDetallesAlumnos(idGrupo);
        
        // Actualizar la gráfica
        actualizarGrafica(detallesAlumnos);
        
        // Actualizar panel de detalles
        actualizarPanelDetalles(detallesAlumnos);
        
        // Actualizar título de la ventana
        String grupoActual = comboGrupos.getSelectedItem().toString();
        setTitle("Estadísticas Gráficas - " + grupoActual);
    }
    
    private void actualizarEstadisticasDirecto(int idGrupo) {
        // Obtener los datos
        List<Object[]> detallesAlumnos = cargarDetallesAlumnos(idGrupo);
        
        // Actualizar la gráfica
        actualizarGrafica(detallesAlumnos);
        
        // Actualizar panel de detalles
        actualizarPanelDetalles(detallesAlumnos);
    }
    
    private List<Object[]> cargarDetallesAlumnos(int idGrupo) {
        List<Object[]> detalles = new ArrayList<>();

        try {
            String query = """
                WITH ActividadesPorAlumno AS (
                    SELECT idActividad
                    FROM Actividad
                    WHERE id_grupo = ?
                )
                SELECT 
                    a.apellido_paterno,
                    a.apellido_materno,
                    a.nombre,
                    COUNT(DISTINCT e.idActividad) AS actividades_realizadas,
                    (SELECT COUNT(*) FROM ActividadesPorAlumno) AS total_actividades_grupo,
                    CASE 
                        WHEN COUNT(e.calificacion) > 0 THEN CAST(AVG(e.calificacion) AS DECIMAL(5,2))
                        ELSE 0
                    END AS promedio_alumno
                FROM 
                    Alumno a
                    LEFT JOIN Evaluacion e ON a.idAlumno = e.idAlumno
                                        AND e.idActividad IN (SELECT idActividad FROM ActividadesPorAlumno)
                WHERE 
                    a.id_grupo = ?
                GROUP BY 
                    a.idAlumno, a.apellido_paterno, a.apellido_materno, a.nombre
                ORDER BY 
                    a.apellido_paterno, a.apellido_materno, a.nombre
            """;

            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idGrupo); // Para ActividadesPorAlumno
            pstmt.setInt(2, idGrupo); // Para Alumno

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getString("apellido_paterno");
                fila[1] = rs.getString("apellido_materno");
                fila[2] = rs.getString("nombre");
                fila[3] = rs.getInt("actividades_realizadas");
                fila[4] = rs.getInt("total_actividades_grupo");
                fila[5] = rs.getDouble("promedio_alumno");
                detalles.add(fila);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener detalles de alumnos: " + e.getMessage());
            e.printStackTrace();
        }

        return detalles;
    }
    
    private void actualizarGrafica(List<Object[]> detallesAlumnos) {
        // Guardar los datos para poder cambiar entre gráficas sin consultar de nuevo
        this.datosAlumnos = detallesAlumnos;
        
        // Contar alumnos por rango de calificación
        int[] contadores = new int[5]; // [<60, 60-69, 70-79, 80-89, 90-100]
        
        for (Object[] detalle : detallesAlumnos) {
            double promedio = (double) detalle[5];
            int porcentaje = (int) (promedio * 10);
            
            if (porcentaje < 60) {
                contadores[0]++;
            } else if (porcentaje <= 69) {
                contadores[1]++;
            } else if (porcentaje <= 79) {
                contadores[2]++;
            } else if (porcentaje <= 89) {
                contadores[3]++;
            } else {
                contadores[4]++;
            }
        }
        
        // Nuevas etiquetas para los rangos
        String[] rangos = {
            "Reprobados (<60)", 
            "Peligro reprobar (60-69)", 
            "Buena calificación (70-79)", 
            "Excelente calificación (80-89)", 
            "Sobresaliente (90-100)"
        };
        
        // Establecer colores para cada rango
        Color[] colores = {
            Color.RED,                  // Reprobados
            new Color(255, 140, 0),     // Naranja - Peligro reprobar
            Color.YELLOW,               // Buena calificación
            new Color(0, 180, 0),       // Verde - Excelente calificación
            new Color(0, 102, 204)      // Azul - Sobresaliente
        };
        
        // Crear gráfica según tipo seleccionado
        JFreeChart chart;
        
        if (tipoGraficaActual == TipoGrafica.BARRAS) {
            // Crear dataset para gráfica de barras
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            
            // En lugar de crear una serie para todos, creamos una serie por cada categoría
            for (int i = 0; i < rangos.length; i++) {
                dataset.addValue(contadores[i], rangos[i], "Alumnos");
            }
            
            // Crear gráfica de barras
            chart = ChartFactory.createBarChart(
                    "Estado del Grupo", 
                    "Categoría", 
                    "Cantidad de Alumnos", 
                    dataset,
                    PlotOrientation.VERTICAL,
                    true, true, false);
            
            // Obtener el plot y el renderer
            CategoryPlot plot = chart.getCategoryPlot();
            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            
            // Aplicar colores a cada serie (cada rango tiene su propia serie)
            for (int i = 0; i < rangos.length; i++) {
                renderer.setSeriesPaint(i, colores[i]);
            }
            
            // Configuración adicional del gráfico
            renderer.setBarPainter(new org.jfree.chart.renderer.category.StandardBarPainter());
            renderer.setShadowVisible(false);
            renderer.setDrawBarOutline(false);
            renderer.setItemMargin(0.1);
            
            // Configurar etiquetas para mostrar el valor sobre cada barra
            renderer.setDefaultItemLabelsVisible(true);
            renderer.setDefaultItemLabelGenerator(new org.jfree.chart.labels.StandardCategoryItemLabelGenerator());
            renderer.setDefaultItemLabelFont(new Font("SansSerif", Font.BOLD, 12));
            
            // Configurar ejes
            CategoryAxis domainAxis = plot.getDomainAxis();
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
            domainAxis.setLowerMargin(0.05);
            domainAxis.setUpperMargin(0.05);
            
            NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            
            // Configurar fondo
            plot.setBackgroundPaint(Color.WHITE);
            plot.setRangeGridlinePaint(Color.LIGHT_GRAY);
            plot.setRangeGridlineStroke(new BasicStroke(1.0f));
            chart.setBackgroundPaint(Color.WHITE);
        } else {
            // Crear dataset para gráfica de pastel
            DefaultPieDataset<String> pieDataset = new DefaultPieDataset<>();
            
            // Agregar datos al dataset
            for (int i = 0; i < rangos.length; i++) {
                if (contadores[i] > 0) { // Solo agregar categorías con valores > 0
                    pieDataset.setValue(rangos[i], contadores[i]);
                }
            }
            
            // Crear gráfica de pastel
            chart = ChartFactory.createPieChart(
                    "Estado del Grupo", 
                    pieDataset,
                    true, // mostrar leyenda
                    true, // mostrar tooltips
                    false); // no mostrar URLs
            
            // Personalizar gráfica de pastel
            org.jfree.chart.plot.PiePlot piePlot = (org.jfree.chart.plot.PiePlot) chart.getPlot();
            
            // Aplicar colores específicos a cada sección
            for (int i = 0; i < rangos.length; i++) {
                piePlot.setSectionPaint(rangos[i], colores[i]);
            }
            
            // Configuraciones adicionales del gráfico de pastel
            piePlot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
            piePlot.setNoDataMessage("No hay datos disponibles");
            piePlot.setCircular(true);
            piePlot.setLabelGap(0.02);
            piePlot.setInteriorGap(0.04);
            piePlot.setLabelGenerator(new org.jfree.chart.labels.StandardPieSectionLabelGenerator(
                    "{0}: {1} ({2})", new java.text.DecimalFormat("0"), new java.text.DecimalFormat("0%")));
            
            // Configurar fondo
            piePlot.setBackgroundPaint(Color.WHITE);
            chart.setBackgroundPaint(Color.WHITE);
        }
        
        // Actualizar panel de gráfico
        chartPanel.setChart(chart);
        chartPanel.repaint();
    }
    
    private void actualizarPanelDetalles(List<Object[]> detallesAlumnos) {
        // Limpiar panel
        panelDetalles.removeAll();
        
        // Contar alumnos por rango
        int[] contadores = new int[5]; // [<60, 60-69, 70-79, 80-89, 90-100]
        
        for (Object[] detalle : detallesAlumnos) {
            double promedio = (double) detalle[5];
            int porcentaje = (int) (promedio * 10);
            
            if (porcentaje < 60) {
                contadores[0]++;
            } else if (porcentaje <= 69) {
                contadores[1]++;
            } else if (porcentaje <= 79) {
                contadores[2]++;
            } else if (porcentaje <= 89) {
                contadores[3]++;
            } else {
                contadores[4]++;
            }
        }
        
        // Crear panel de información
        JPanel infoPanel = new JPanel(new GridLayout(7, 2, 10, 5));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Añadir información por rango
        String[] rangos = {
            "Reprobados (<60)", 
            "Peligro reprobar (60-69)", 
            "Buena calificación (70-79)", 
            "Excelente calificación (80-89)", 
            "Sobresaliente (90-100)"
        };
        
        infoPanel.add(new JLabel("Rango", JLabel.CENTER));
        infoPanel.add(new JLabel("Cantidad", JLabel.CENTER));
        
        for (int i = 0; i < rangos.length; i++) {
            JLabel labelRango = new JLabel(rangos[i], JLabel.CENTER);
            JLabel labelCantidad = new JLabel(String.valueOf(contadores[i]), JLabel.CENTER);
            
            infoPanel.add(labelRango);
            infoPanel.add(labelCantidad);
        }
        
        // Añadir total
        infoPanel.add(new JLabel("TOTAL", JLabel.CENTER));
        infoPanel.add(new JLabel(String.valueOf(detallesAlumnos.size()), JLabel.CENTER));
        
        // Añadir a panel principal
        panelDetalles.add(infoPanel);
        
        // Actualizar vista
        panelDetalles.revalidate();
        panelDetalles.repaint();
    }
    
    private void cambiarTipoGrafica() {
        if (tipoGraficaActual == TipoGrafica.BARRAS) {
            tipoGraficaActual = TipoGrafica.PASTEL;
            btnTipoGrafica.setText("Cambiar a Barras");
        } else {
            tipoGraficaActual = TipoGrafica.BARRAS;
            btnTipoGrafica.setText("Cambiar a Pastel");
        }
        
        // Si tenemos datos almacenados, actualizamos directamente la gráfica
        if (datosAlumnos != null && !datosAlumnos.isEmpty()) {
            actualizarGrafica(datosAlumnos);
        } else if (idGrupoActual != -1) {
            // Si no tenemos datos pero sí tenemos un ID de grupo, actualizamos las estadísticas
            actualizarEstadisticasDirecto(idGrupoActual);
        } else {
            // En caso contrario, actualizamos normalmente
            actualizarEstadisticas();
        }
    }
    
    private void exportarAPDF() {
        try {
            // Permitir al usuario elegir dónde guardar el archivo
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Guardar estadísticas como PDF");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
                @Override
                public boolean accept(File f) {
                    return f.isDirectory() || f.getName().toLowerCase().endsWith(".pdf");
                }
                
                @Override
                public String getDescription() {
                    return "Archivos PDF (*.pdf)";
                }
            });
            fileChooser.setSelectedFile(new File("estadisticas_" + nombreGrupo.replaceAll("[^a-zA-Z0-9]", "_") + ".pdf"));
            
            int resultado = fileChooser.showSaveDialog(this);
            if (resultado != JFileChooser.APPROVE_OPTION) {
                return; // Usuario canceló
            }
            
            File archivo = fileChooser.getSelectedFile();
            // Añadir extensión .pdf si no la tiene
            if (!archivo.getAbsolutePath().toLowerCase().endsWith(".pdf")) {
                archivo = new File(archivo.getAbsolutePath() + ".pdf");
            }
            
            // Crear documento PDF
            Document documento = new Document();
            PdfWriter.getInstance(documento, new FileOutputStream(archivo));
            documento.open();
            
            // Agregar título y fecha
            documento.addCreationDate();
            
            // Crear fuente para título (negrita, tamaño 18, gris oscuro)
            com.itextpdf.text.Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            fontTitulo.setColor(new BaseColor(80, 80, 80));
            
            Paragraph titulo = new Paragraph("Estadísticas Gráficas - " + nombreGrupo, fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(20);
            documento.add(titulo);
            
            // Agregar subtítulo con el tipo de gráfica
            // Crear fuente normal (tamaño 14, gris oscuro)
            com.itextpdf.text.Font fontNormal = FontFactory.getFont(FontFactory.HELVETICA, 14);
            fontNormal.setColor(new BaseColor(80, 80, 80));
            
            String tipoGrafica = (tipoGraficaActual == TipoGrafica.BARRAS) ? "Gráfica de barras" : "Gráfica de pastel";
            Paragraph subtitulo = new Paragraph("Tipo: " + tipoGrafica, fontNormal);
            subtitulo.setAlignment(Element.ALIGN_CENTER);
            subtitulo.setSpacingAfter(20);
            documento.add(subtitulo);
            
            // Agregar gráfica - capturar imagen del gráfico actual
            JFreeChart chart = chartPanel.getChart();
            java.awt.image.BufferedImage bufferedImage = chart.createBufferedImage(800, 400);
            
            // Convertir BufferedImage a bytes para iText
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", baos);
            Image imagen = Image.getInstance(baos.toByteArray());
            imagen.setAlignment(Element.ALIGN_CENTER);
            imagen.scaleToFit(500, 300); // Ajustar tamaño
            imagen.setSpacingAfter(20);
            documento.add(imagen);
            
            // Agregar detalles en tabla
            // Crear fuente para encabezados de tabla (negrita, tamaño 12, blanco)
            com.itextpdf.text.Font fontHeaderTabla = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
            fontHeaderTabla.setColor(BaseColor.WHITE);
            
            // Crear fuente para contenido de tabla (normal, tamaño 11, negro)
            com.itextpdf.text.Font fontContenidoTabla = FontFactory.getFont(FontFactory.HELVETICA, 11);
            fontContenidoTabla.setColor(BaseColor.BLACK);
            
            PdfPTable tabla = new PdfPTable(2);
            tabla.setWidthPercentage(90);
            tabla.setSpacingBefore(10);
            tabla.setSpacingAfter(10);
            
            // Añadir encabezados
            PdfPCell celdaHeader = new PdfPCell(new Phrase("Rango", fontHeaderTabla));
            celdaHeader.setBackgroundColor(new BaseColor(79, 129, 189)); // Azul
            celdaHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaHeader.setPadding(5);
            tabla.addCell(celdaHeader);
            
            celdaHeader = new PdfPCell(new Phrase("Cantidad", fontHeaderTabla));
            celdaHeader.setBackgroundColor(new BaseColor(79, 129, 189)); // Azul
            celdaHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaHeader.setPadding(5);
            tabla.addCell(celdaHeader);
            
            // Añadir detalles por rango
            String[] rangos = {
                "Reprobados (<60)", 
                "Peligro reprobar (60-69)", 
                "Buena calificación (70-79)", 
                "Excelente calificación (80-89)", 
                "Sobresaliente (90-100)"
            };
            
            // Colores correspondientes a cada rango
            BaseColor[] coloresPDF = {
                new BaseColor(255, 0, 0),         // Rojo - Reprobados
                new BaseColor(255, 140, 0),       // Naranja - Peligro
                new BaseColor(255, 255, 0),       // Amarillo - Buena
                new BaseColor(0, 180, 0),         // Verde - Excelente
                new BaseColor(0, 102, 204)        // Azul - Sobresaliente
            };
            
            int[] contadores = new int[5]; // [<60, 60-69, 70-79, 80-89, 90-100]
            
            for (Object[] detalle : datosAlumnos) {
                double promedio = (double) detalle[5];
                int porcentaje = (int) (promedio * 10);
                
                if (porcentaje < 60) {
                    contadores[0]++;
                } else if (porcentaje <= 69) {
                    contadores[1]++;
                } else if (porcentaje <= 79) {
                    contadores[2]++;
                } else if (porcentaje <= 89) {
                    contadores[3]++;
                } else {
                    contadores[4]++;
                }
            }
            
            for (int i = 0; i < rangos.length; i++) {
                PdfPCell celda = new PdfPCell(new Phrase(rangos[i], fontContenidoTabla));
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setPadding(5);
                // Aplicar color más suave de fondo
                BaseColor colorSuave = new BaseColor(
                    255 - ((255 - coloresPDF[i].getRed()) / 2),
                    255 - ((255 - coloresPDF[i].getGreen()) / 2),
                    255 - ((255 - coloresPDF[i].getBlue()) / 2)
                );
                celda.setBackgroundColor(colorSuave);
                tabla.addCell(celda);
                
                celda = new PdfPCell(new Phrase(String.valueOf(contadores[i]), fontContenidoTabla));
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setPadding(5);
                celda.setBackgroundColor(colorSuave);
                tabla.addCell(celda);
            }
            
            // Añadir total
            PdfPCell celdaTotal = new PdfPCell(new Phrase("TOTAL", fontHeaderTabla));
            celdaTotal.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaTotal.setBackgroundColor(new BaseColor(79, 129, 189)); // Azul
            celdaTotal.setPadding(5);
            tabla.addCell(celdaTotal);
            
            celdaTotal = new PdfPCell(new Phrase(String.valueOf(datosAlumnos.size()), fontHeaderTabla));
            celdaTotal.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaTotal.setBackgroundColor(new BaseColor(79, 129, 189)); // Azul
            celdaTotal.setPadding(5);
            tabla.addCell(celdaTotal);
            
            documento.add(tabla);
            
            // Agregar pie de página
            Paragraph footer = new Paragraph("Documento generado el " + new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date()), fontContenidoTabla);
            footer.setAlignment(Element.ALIGN_RIGHT);
            footer.setSpacingBefore(20);
            documento.add(footer);
            
            // Cerrar documento
            documento.close();
            
            // Preguntar si desea abrir el PDF
            int abrirPDF = JOptionPane.showConfirmDialog(this, 
                    "El PDF se ha guardado exitosamente en:\n" + archivo.getAbsolutePath() + "\n\n¿Desea abrirlo ahora?", 
                    "PDF Generado", 
                    JOptionPane.YES_NO_OPTION);
            
            if (abrirPDF == JOptionPane.YES_OPTION) {
                // Abrir el PDF con el visor predeterminado
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivo);
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede abrir automáticamente el PDF. Se encuentra en:\n" + archivo.getAbsolutePath());
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al exportar a PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    /**
     * Método público para seleccionar un grupo específico por su ID
     * @param idGrupo ID del grupo a seleccionar
     */
    public void seleccionarGrupo(int idGrupoSeleccionar) {
        // Recorrer todos los elementos del combobox
        for (int i = 0; i < comboGrupos.getItemCount(); i++) {
            String item = comboGrupos.getItemAt(i);
            // Extraer el ID del grupo del texto del ítem
            try {
                int idGrupo = Integer.parseInt(item.substring(item.lastIndexOf("ID: ") + 4, item.length() - 1));
                if (idGrupo == idGrupoSeleccionar) {
                    // Seleccionar el ítem y actualizar estadísticas
                    comboGrupos.setSelectedIndex(i);
                    actualizarEstadisticas();
                    return;
                }
            } catch (Exception e) {
                System.err.println("Error al procesar ID de grupo: " + e.getMessage());
            }
        }
        // Si no se encuentra el grupo, mostrar un mensaje
        System.out.println("No se encontró el grupo con ID: " + idGrupoSeleccionar);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstadisticasGraficas ventana = new EstadisticasGraficas();
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
        });
    }
}
