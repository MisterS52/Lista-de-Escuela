/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfas;

import javax.swing.JFrame;
import java.sql.SQLException;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.ButtonGroup;
import com.mycompany.escuela.Grupo;
import com.mycompany.escuela.GrupoDAO;

/**
 *
 * @author Jovanni SG
 */
public class EstadoDelGrupo extends javax.swing.JFrame {

   InicideClase pantallaPrincipale; // Referencia a la pantalla principal
    private GrupoDAO grupoDAO = new GrupoDAO(); // DAO para base de datos
    private DefaultListModel<String> modeloLista = new DefaultListModel<>();
    private List<String> listaGruposActual; // Guardar lista actual para acceder por índice
    
    public EstadoDelGrupo(InicideClase pantallas) {
     this.pantallaPrincipale = pantallas;
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ListadeGrupos.setModel(modeloLista); // Asignar modelo a la lista
        agruparRadioButtons();
        cargarGrupos(); // Carga inicial de grupos
    }
    
    // Agrupar los RadioButton para que solo uno se seleccione a la vez
    private void agruparRadioButtons() {
        ButtonGroup grupoBotones = new ButtonGroup();
        grupoBotones.add(MosActivos);
        grupoBotones.add(MosDesactivos);
    }

    // Cargar todos los grupos al inicio
    private void cargarGrupos() {
        try {
            listaGruposActual = grupoDAO.obtenerTodosLosGrupos();
            actualizarLista(listaGruposActual);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar grupos: " + e.getMessage());
        }
    }
     // Actualizar el JList con la lista dada
    private void actualizarLista(List<String> lista) {
        DefaultListModel<String> modelo = new DefaultListModel<>();
for (String grupo : listaGruposActual) {
    modelo.addElement(grupo);
}
ListadeGrupos.setModel(modelo);

    }

    // Mostrar solo grupos activos
    private void mostrarActivos() {
        try {
            listaGruposActual = grupoDAO.obtenerGruposActivos();
            actualizarLista(listaGruposActual);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar grupos activos: " + e.getMessage());
        }
    }

    // Mostrar solo grupos desactivados
    private void mostrarDesactivos() {
        try {
            listaGruposActual = grupoDAO.obtenerGruposDesactivados();
            actualizarLista(listaGruposActual);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar grupos desactivados: " + e.getMessage());
        }
    }

    // ACTIVAR grupo seleccionado
    private void activarGrupo() {
       int index = ListadeGrupos.getSelectedIndex();
    if (index != -1) {
        String detalleGrupo = listaGruposActual.get(index); // Aquí es un String

        // Extraer el ID del grupo usando split
        int idGrupo = extraerIdGrupo(detalleGrupo);

        // Revisar si ya está activo (opcionalmente podrías también extraer esto del String)
        if (detalleGrupo.contains("Activo")) {
            JOptionPane.showMessageDialog(this, "El grupo ya está activo.");
            return;
        }

        try {
            grupoDAO.actualizarEstadoActivo(idGrupo, true);
            JOptionPane.showMessageDialog(this, "Grupo activado correctamente.");
            recargarLista();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al activar el grupo: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Seleccione un grupo de la lista.");
    }
    }
    
    // Método para extraer el idGrupo del String (asumiendo que siempre empieza con "ID: número")
private int extraerIdGrupo(String detalle) {
    try {
        String[] partes = detalle.split("\\|");
        for (String parte : partes) {
            parte = parte.trim();
            if (parte.startsWith("ID:")) {
                String idStr = parte.replace("ID:", "").trim();
                return Integer.parseInt(idStr);
            }
        }
    } catch (Exception e) {
        System.err.println("Error al extraer ID del grupo: " + e.getMessage());
    }
    return -1; // Retornar un valor inválido si no encuentra el ID
}

    // DESACTIVAR grupo seleccionado
    private void desactivarGrupo() {
         int index = ListadeGrupos.getSelectedIndex();
    if (index != -1) {
        String detalleGrupo = listaGruposActual.get(index); // Obtenemos el String

        // Extraemos el ID del grupo
        int idGrupo = extraerIdGrupo(detalleGrupo);

        // Revisar si ya está desactivado
        if (detalleGrupo.contains("Desactivado")) {
            JOptionPane.showMessageDialog(this, "El grupo ya está desactivado.");
            return;
        }

        try {
            grupoDAO.actualizarEstadoActivo(idGrupo, false); // Ponemos en false para desactivar
            JOptionPane.showMessageDialog(this, "Grupo desactivado correctamente.");
            recargarLista(); // Actualizamos la lista
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al desactivar el grupo: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Seleccione un grupo de la lista.");
    }
    }

    // Recarga según botón seleccionado
    private void recargarLista() {
        if (MosActivos.isSelected()) {
            mostrarActivos();
        } else if (MosDesactivos.isSelected()) {
            mostrarDesactivos();
        } else {
            cargarGrupos();
        }
    }

 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ListadeGrupos = new javax.swing.JList<>();
        MosActivos = new javax.swing.JRadioButton();
        MosDesactivos = new javax.swing.JRadioButton();
        Desactivar = new javax.swing.JButton();
        Activar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Este apartado es para Activar o Desatibar a los Grupos Escolares ");

        ListadeGrupos.setBackground(new java.awt.Color(204, 204, 204));
        ListadeGrupos.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        ListadeGrupos.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(ListadeGrupos);

        MosActivos.setBackground(new java.awt.Color(153, 153, 153));
        MosActivos.setForeground(new java.awt.Color(255, 255, 255));
        MosActivos.setText("Mostrar Activos");
        MosActivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MosActivosActionPerformed(evt);
            }
        });

        MosDesactivos.setBackground(new java.awt.Color(153, 153, 153));
        MosDesactivos.setForeground(new java.awt.Color(255, 255, 255));
        MosDesactivos.setText("Mostrar Desactivos");
        MosDesactivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MosDesactivosActionPerformed(evt);
            }
        });

        Desactivar.setBackground(new java.awt.Color(153, 153, 153));
        Desactivar.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        Desactivar.setForeground(new java.awt.Color(255, 255, 255));
        Desactivar.setText("Desactivar");
        Desactivar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesactivarActionPerformed(evt);
            }
        });

        Activar.setBackground(new java.awt.Color(153, 153, 153));
        Activar.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        Activar.setForeground(new java.awt.Color(255, 255, 255));
        Activar.setText("Activar");
        Activar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActivarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(68, 68, 68))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(MosDesactivos)
                                .addGap(310, 310, 310)
                                .addComponent(Desactivar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(MosActivos)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Activar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MosActivos)
                    .addComponent(Activar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MosDesactivos)
                    .addComponent(Desactivar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DesactivarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesactivarActionPerformed
         desactivarGrupo();
    }//GEN-LAST:event_DesactivarActionPerformed

    private void ActivarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActivarActionPerformed
        // TODO add your handling code here:
        activarGrupo();
    }//GEN-LAST:event_ActivarActionPerformed

    private void MosActivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MosActivosActionPerformed
        // TODO add your handling code here:
         mostrarActivos();
    }//GEN-LAST:event_MosActivosActionPerformed

    private void MosDesactivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MosDesactivosActionPerformed
        // TODO add your handling code here:
         mostrarDesactivos();
    }//GEN-LAST:event_MosDesactivosActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Activar;
    private javax.swing.JButton Desactivar;
    private javax.swing.JList<String> ListadeGrupos;
    private javax.swing.JRadioButton MosActivos;
    private javax.swing.JRadioButton MosDesactivos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
