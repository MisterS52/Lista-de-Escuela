package Interfas;

import com.mycompany.escuela.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class estadisticas extends JFrame {
    private JComboBox<String> comboGrupos;
    private JTable tablaEstadisticas;
    private JTable tablaAlumnos;
    private DefaultTableModel modeloTablaEstadisticas;
    private DefaultTableModel modeloTablaAlumnos;
    private Connection conn;
    private JSplitPane splitPane;

    public estadisticas() {
        setTitle("Estadísticas de Calificaciones por Grupo");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        conectarBaseDatos();
        cargarGrupos();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        
        // Panel superior para seleccionar grupo
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        comboGrupos = new JComboBox<>();
        panelSuperior.add(new JLabel("Seleccionar Grupo: "));
        panelSuperior.add(comboGrupos);
        add(panelSuperior, BorderLayout.NORTH);
        
        // Panel para tabla de estadísticas
        JPanel panelEstadisticas = new JPanel(new BorderLayout());
        panelEstadisticas.setBorder(BorderFactory.createTitledBorder("Estadísticas por Rango"));
        
        String[] columnasEstadisticas = {"Rango de Calificación", "Cantidad de Alumnos"};
        modeloTablaEstadisticas = new DefaultTableModel(columnasEstadisticas, 0);
        tablaEstadisticas = new JTable(modeloTablaEstadisticas);
        tablaEstadisticas.setRowHeight(30);
        tablaEstadisticas.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        
        JScrollPane scrollEstadisticas = new JScrollPane(tablaEstadisticas);
        panelEstadisticas.add(scrollEstadisticas, BorderLayout.CENTER);
        
        // Panel para tabla de alumnos con promedios
        JPanel panelAlumnos = new JPanel(new BorderLayout());
        panelAlumnos.setBorder(BorderFactory.createTitledBorder("Detalle de Alumnos"));
        
        String[] columnasAlumnos = {"Apellido Paterno", "Apellido Materno", "Nombre", "Actividades Realizadas", "Total Actividades", "Promedio"};
        modeloTablaAlumnos = new DefaultTableModel(columnasAlumnos, 0);
        tablaAlumnos = new JTable(modeloTablaAlumnos);
        tablaAlumnos.setRowHeight(25);
        tablaAlumnos.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        
        JScrollPane scrollAlumnos = new JScrollPane(tablaAlumnos);
        panelAlumnos.add(scrollAlumnos, BorderLayout.CENTER);
        
        // Crear un SplitPane para dividir la pantalla
        splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelEstadisticas, panelAlumnos);
        splitPane.setDividerLocation(250);
        add(splitPane, BorderLayout.CENTER);
        
        // Panel inferior con botones
        JPanel panelInferior = new JPanel();
        JButton btnActualizar = new JButton("Actualizar Estadísticas");
        btnActualizar.addActionListener(e -> actualizarEstadisticas());
        panelInferior.add(btnActualizar);
        add(panelInferior, BorderLayout.SOUTH);
        
        // Agregar listener al combo
        comboGrupos.addActionListener(e -> actualizarEstadisticas());
    }

    private void conectarBaseDatos() {
         try {
        conn = DatabaseConnection.getConnection();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
    }
    }

    private void cargarGrupos() {
        try {
            String query = "SELECT DISTINCT g.idgrupo, g.grado, g.grupo, g.turno, g.nombremateria " +
                          "FROM Grupo g WHERE g.activo = true " +
                          "ORDER BY g.grado, g.grupo";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            comboGrupos.removeAllItems();
            while (rs.next()) {
                String grupoInfo = String.format("%s°%s - %s - %s (ID: %d)", 
                    rs.getString("grado"),
                    rs.getString("grupo"),
                    rs.getString("turno"),
                    rs.getString("nombremateria"),
                    rs.getInt("idgrupo"));
                comboGrupos.addItem(grupoInfo);
            }
            
            // Seleccionar el primer elemento por defecto
            if (comboGrupos.getItemCount() > 0) {
                comboGrupos.setSelectedIndex(0);
                actualizarEstadisticas();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar grupos: " + e.getMessage());
        }
    }

    private int getSelectedGroupId() {
        if (comboGrupos.getSelectedItem() == null) return -1;
        
        String seleccion = comboGrupos.getSelectedItem().toString();
        return Integer.parseInt(seleccion.substring(seleccion.lastIndexOf("ID: ") + 4, seleccion.length() - 1));
    }

    private void actualizarEstadisticas() {
        int idGrupo = getSelectedGroupId();
        if (idGrupo == -1) return;

        // Primero cargar detalles de alumnos
        List<Object[]> detallesAlumnos = cargarDetallesAlumnos(idGrupo);
        
        // Luego actualizar tabla de alumnos con los detalles cargados
        actualizarTablaAlumnos(detallesAlumnos);
        
        // Finalmente actualizar tabla de estadísticas usando los mismos datos
        actualizarTablaEstadisticas(detallesAlumnos);
        
        // Actualizar título de la ventana
        String grupoActual = comboGrupos.getSelectedItem().toString();
        setTitle("Estadísticas de Calificaciones - " + grupoActual);
    }
    
    private List<Object[]> cargarDetallesAlumnos(int idGrupo) {
        List<Object[]> detalles = new ArrayList<>();

        try {
            String query = """
                WITH ActividadesPorAlumno AS (
                    SELECT idActividad
                    FROM Actividad
                    WHERE id_grupo = ?
                )
                SELECT 
                    a.apellido_paterno,
                    a.apellido_materno,
                    a.nombre,
                    COUNT(DISTINCT e.idActividad) AS actividades_realizadas,
                    (SELECT COUNT(*) FROM ActividadesPorAlumno) AS total_actividades_grupo,
                    CASE 
                        WHEN COUNT(e.calificacion) > 0 THEN ROUND(AVG(e.calificacion))
                        ELSE 0
                    END AS promedio_alumno
                FROM 
                    Alumno a
                    LEFT JOIN Evaluacion e ON a.idAlumno = e.idAlumno
                                        AND e.idActividad IN (SELECT idActividad FROM ActividadesPorAlumno)
                WHERE 
                    a.id_grupo = ?
                GROUP BY 
                    a.idAlumno, a.apellido_paterno, a.apellido_materno, a.nombre
                ORDER BY 
                    a.apellido_paterno, a.apellido_materno, a.nombre
            """;

            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idGrupo); // Para ActividadesPorAlumno
            pstmt.setInt(2, idGrupo); // Para Alumno

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getString("apellido_paterno");
                fila[1] = rs.getString("apellido_materno");
                fila[2] = rs.getString("nombre");
                fila[3] = rs.getInt("actividades_realizadas");
                fila[4] = rs.getInt("total_actividades_grupo");
                fila[5] = rs.getInt("promedio_alumno");
                detalles.add(fila);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener detalles de alumnos: " + e.getMessage());
            e.printStackTrace();
        }

        return detalles;
    }
    
    private void actualizarTablaAlumnos(List<Object[]> detallesAlumnos) {
        // Limpiar la tabla
        modeloTablaAlumnos.setRowCount(0);
        
        // Agregar los resultados a la tabla
        for (Object[] detalle : detallesAlumnos) {
            modeloTablaAlumnos.addRow(detalle);
        }
    }
    
    private void actualizarTablaEstadisticas(List<Object[]> detallesAlumnos) {
        modeloTablaEstadisticas.setRowCount(0);
        int[] contadores = new int[5]; // [<60, 60-69, 70-79, 80-89, 90-100]

        for (Object[] detalle : detallesAlumnos) {
            int promedio = Integer.parseInt(detalle[5].toString());
            int porcentaje = promedio * 10;

            if (porcentaje < 60) {
                contadores[0]++;
            } else if (porcentaje <= 69) {
                contadores[1]++;
            } else if (porcentaje <= 79) {
                contadores[2]++;
            } else if (porcentaje <= 89) {
                contadores[3]++;
            } else {
                contadores[4]++;
            }
        }

        String[] rangos = {"Menos de 60", "60-69", "70-79", "80-89", "90-100"};
        for (int i = 0; i < rangos.length; i++) {
            modeloTablaEstadisticas.addRow(new Object[]{rangos[i], contadores[i]});
        }

        modeloTablaEstadisticas.addRow(new Object[]{"TOTAL ALUMNOS", detallesAlumnos.size()});
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            estadisticas ventana = new estadisticas();
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
        });
    }
}