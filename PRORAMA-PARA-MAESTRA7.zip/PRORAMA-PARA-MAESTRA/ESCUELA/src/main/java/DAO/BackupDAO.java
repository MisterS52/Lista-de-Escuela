package DAO;

import com.mycompany.escuela.DatabaseConnection;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BackupDAO {
    public static boolean realizarBackup() {
        try {
            // Ruta al ejecutable de pg_dump
            String pgDump = "\"C:\\Program Files\\PostgreSQL\\17\\bin\\pg_dump.exe\"";

            // Leer la ruta base desde el archivo ruta.txt
            String rutaBase = leerRutaDesdeArchivo(); // Nueva función

            if (rutaBase == null || rutaBase.isEmpty()) {
                System.out.println("No se encontró la ruta para guardar el backup.");
                return false;
            }

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String fecha = formatoFecha.format(new Date());

            // Crear ruta completa para el backup
            String ruta = rutaBase + "\\\\Archivo_" + fecha + ".backup";

            String[] comando = {
                pgDump,
                "-h", "localhost",
                "-p", "5432",
                "-U", "postgres",
                "-F", "c",
                "-d", "Escuela",
                "-f", ruta
            };

            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.environment().put("PGPASSWORD", DatabaseConnection.getPassword());
            Process process = pb.start();
            int resultado = process.waitFor();

            if (resultado == 0) {
                System.out.println("Backup realizado con exito: " + ruta);
                return true;
            } else {
                System.out.println("Error al realizar el backup.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    // Método para leer la ruta del archivo "ruta.txt"
    private static String leerRutaDesdeArchivo() {
        try {
            File archivo = new File("ruta.txt");
            if (archivo.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(archivo));
                String linea = br.readLine();
                br.close();
                return linea;
            } else {
                System.out.println("El archivo ruta.txt no existe.");
                return null;
            }
        } catch (IOException e) {
            System.out.println("Error leyendo la ruta desde archivo: " + e.getMessage());
            return null;
        }
    }
}