/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escuela;

import javax.swing.*;
import java.awt.*;

public class PanelConFondo4 extends JPanel {
    private Image imagen;

    public PanelConFondo4() {
        ImageIcon icon = new ImageIcon(getClass().getResource("/Imagenes/niño.png"));
        imagen = icon.getImage();
        setOpaque(false); // Importante para que los componentes se vean sobre la imagen
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
