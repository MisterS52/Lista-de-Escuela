package DAO;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BackupDAO {
    public static boolean realizarBackup() {
        try {
            String pgDump = "\"C:\\Program Files\\PostgreSQL\\17\\bin\\pg_dump.exe\""; // Ruta pg_dump
            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String fecha = formatoFecha.format(new Date());
            
            // 🔥 Aquí va tu ruta con doble barra invertida (\\)
            String ruta = "F:\\SEÑOR S\\UDG\\7-semestre\\IngeriaSoftware2\\PRORAMA-PARA-MAESTRA\\Backup\\Escuela_" + fecha + ".backup";

            String[] comando = {
                pgDump,
                "-h", "localhost",       // Host
                "-p", "5432",           // Puerto
                "-U", "postgres",       // Usuario
                "-F", "c",              // Formato Custom
                "-d", "Escuela",        // Nombre de la base de datos
                "-f", ruta
            };

            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.environment().put("PGPASSWORD", "36379025"); // Contraseña
            Process process = pb.start();
            int resultado = process.waitFor();
            
            if (resultado == 0) {
                System.out.println("✅ Backup realizado con éxito: " + ruta);
                return true;
            } else {
                System.out.println("❌ Error al realizar el backup.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            return false;
        }
    }
}

