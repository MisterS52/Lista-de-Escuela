CREATE TABLE Escuela(

nombre varchar(150),
direccion varchar(150),
clave varchar(30),
PRIMARY KEY (nombre)

);

CREATE TABLE Grupo(

idgrupo serial,
grado varchar(2),
grupo varchar(2),
turno varchar(12),
escuela_nombre varchar(150),
FOREIGN KEY (escuela_nombre) REFERENCES Escuela(nombre),
PRIMARY KEY (idgrupo)
);

CREATE TABLE Alumno(

idAlumno serial,
nombre varchar(150),
apellido_paterno varchar(150),
apellido_materno varchar(150),
id_grupo integer,
FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo),
PRIMARY KEY (idAlumno)
);

CREATE TABLE Fechas_asistencia(

idFecha serial,
fecha date, 
id_grupo integer,
FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo),
PRIMARY KEY (idFecha)
);

CREATE TABLE Actividad(

idActividad serial,
fecha date,
id_grupo integer,
FOREIGN KEY (id_grupo) REFERENCES Grupo(idgrupo),
PRIMARY KEY (idActividad)
);

CREATE TABLE Asistencia(

idAsistencia serial,
idFecha integer, 
FOREIGN KEY (idFecha) REFERENCES Fechas_asistencia(idFecha),
idAlumno integer,
FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
asistencia integer,
PRIMARY KEY (idAsistencia)
);

CREATE TABLE Evaluacion(
idEvaluacion serial,
idAlumno integer,
FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
idActividad integer,
FOREIGN KEY (idActividad) REFERENCES Actividad(idActividad),
calificacion integer,
PRIMARY KEY (idEvaluacion)
);

ALTER USER postgres WITH PASSWORD '36379025';

show table
ALTER TABLE Actividad
ADD COLUMN NombreActividad VARCHAR(255);
ALTER TABLE Grupo
ADD COLUMN NombreMateria VARCHAR(255);
ALTER TABLE Escuela
ADD COLUMN TipoEscuela VARCHAR(255);
ALTER TABLE Grupo
ADD COLUMN AñoDeInicio VARCHAR(255);
ALTER TABLE grupo ADD COLUMN activo BOOLEAN DEFAULT TRUE;
------------------------------------------------------------------------------------------------------------------------
ALTER TABLE Asistencia 
ADD COLUMN no_Duplicado TEXT GENERATED ALWAYS AS (idFecha || '-' || idAlumno) STORED;
ALTER TABLE Asistencia 
ADD CONSTRAINT unique_no_duplicado UNIQUE (no_Duplicado);
-------------------------------------------------------------------------------------------------------------------------
ALTER TABLE evaluacion 
ADD COLUMN no_Duplicado TEXT GENERATED ALWAYS AS (idactividad || '-' || idAlumno) STORED;
ALTER TABLE evaluacion 
ADD CONSTRAINT unique_no_duplicados UNIQUE (no_Duplicado);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Si ya tienes registros duplicados en tu tabla, la restricción UNIQUE fallará. Debes limpiar los datos antes de agregar la restricción con:
DELETE FROM Asistencia 
WHERE idAsistencia NOT IN (
    SELECT MIN(idAsistencia) 
    FROM Asistencia 
    GROUP BY idFecha, idAlumno
);
DELETE FROM Evaluacion 
WHERE idevaluacion NOT IN (
    SELECT MIN(idevaluacion) 
    FROM Evaluacion 
    GROUP BY idActividad, idAlumno
);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Agregar la Columna y un Trigger (Se almacena el Promedio y se actualiza automáticamente)
ALTER TABLE Alumno ADD COLUMN Promedio DECIMAL(5,2);

CREATE OR REPLACE FUNCTION actualizar_promedio()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE Alumno
    SET Promedio = (
        SELECT COALESCE(AVG(calificacion), 0)
        FROM Evaluacion
        WHERE idAlumno = NEW.idAlumno
    )
    WHERE idAlumno = NEW.idAlumno;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_actualizar_promedio
AFTER INSERT OR UPDATE OR DELETE ON Evaluacion
FOR EACH ROW EXECUTE FUNCTION actualizar_promedio();

UPDATE Alumno
SET Promedio = (
    SELECT COALESCE(AVG(calificacion), 0)
    FROM Evaluacion
    WHERE Evaluacion.idAlumno = Alumno.idAlumno
);
-------------------------------------------------------------------------------------------------------------------------
ALTER TABLE Alumno ADD COLUMN PorcentajeAsistencia DECIMAL(5,2) DEFAULT 0;

CREATE OR REPLACE FUNCTION actualizar_porcentaje_asistencia()
RETURNS TRIGGER AS $$
DECLARE
    total_asistencias INTEGER;
    total_registros INTEGER;
    porcentaje DECIMAL(5,2);
BEGIN
    -- Contar cuántas veces asistió el alumno (se asume que 1 es presente, 0 es ausente)
    SELECT COUNT(*) INTO total_asistencias
    FROM Asistencia
    WHERE idAlumno = NEW.idAlumno AND asistencia = 1;

    -- Contar el total de registros de asistencia del alumno
    SELECT COUNT(*) INTO total_registros
    FROM Asistencia
    WHERE idAlumno = NEW.idAlumno;

    -- Calcular el porcentaje (evitando división por cero)
    IF total_registros > 0 THEN
        porcentaje := (total_asistencias * 100.0) / total_registros;
    ELSE
        porcentaje := 0;
    END IF;

    -- Actualizar el porcentaje en la tabla Alumno
    UPDATE Alumno
    SET PorcentajeAsistencia = porcentaje
    WHERE idAlumno = NEW.idAlumno;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
////////////////////////////////////////////////////////////////////
DROP TRIGGER IF EXISTS trigger_actualizar_asistencia ON Asistencia;

CREATE TRIGGER trigger_actualizar_asistencia
AFTER INSERT OR UPDATE OR DELETE ON Asistencia
FOR EACH ROW EXECUTE FUNCTION actualizar_porcentaje_asistencia();

UPDATE Alumno
SET PorcentajeAsistencia = (
    SELECT COALESCE(AVG(asistencia), 0)
    FROM Asistencia
    WHERE Asistencia.idAlumno = Alumno.idAlumno
);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
show table
SELECT * FROM evaluacion;
SELECT * FROM actividad;
SELECT * FROM fechas_asistencia;
SELECT * FROM alumno;
SELECT * FROM Asistencia;
SELECT * FROM grupo;
SELECT * FROM escuela;