package Interfas;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.pdf.PdfPCell;
import com.mycompany.escuela.DatabaseConnection;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.*;
import java.io.FileOutputStream;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;

public class ModuloPDF extends JFrame {
    private JTextField txtBusqueda;
    private JTable tablaAlumnos;
    private JButton btnBuscar;
    private JButton btnGenerarPDF;
    private JButton btnVistaPrevia;
    private DefaultTableModel modeloTabla;
    private Connection conn;
    private JPanel panelVistaPrevia;
    private JTextArea txtVistaPrevia;
    private int idGrupoActual;

    public ModuloPDF(int idGrupo) {
        this.idGrupoActual = idGrupo;
        initComponents();
        conectarBaseDatos();
        cargarAlumnosDelGrupo();
    }

   private void conectarBaseDatos() {
    try {
        Class.forName("org.postgresql.Driver");
        conn = DatabaseConnection.getConnection();

        if (conn == null) {
            throw new SQLException("No se pudo establecer la conexión");
        }

    } catch (ClassNotFoundException e) {
        JOptionPane.showMessageDialog(this, 
            "Error: No se encontró el driver de PostgreSQL\n" + e.getMessage(),
            "Error de Conexión",
            JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, 
            "Error al conectar a la base de datos:\n" + e.getMessage(),
            "Error de Conexión",
            JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }
}

    private void initComponents() {
        setTitle("Generador de Reportes PDF");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtBusqueda = new JTextField(20);
        btnBuscar = new JButton("Buscar");
        panelBusqueda.add(new JLabel("Buscar por nombre o ID:"));
        panelBusqueda.add(txtBusqueda);
        panelBusqueda.add(btnBuscar);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        String[] columnas = {"ID", "Nombre", "Apellido Paterno", "Apellido Materno", "Grupo", "Escuela"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaAlumnos = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaAlumnos);
        panelIzquierdo.add(scrollPane, BorderLayout.CENTER);

        panelVistaPrevia = new JPanel(new BorderLayout());
        txtVistaPrevia = new JTextArea();
        txtVistaPrevia.setEditable(false);
        JScrollPane scrollVistaPrevia = new JScrollPane(txtVistaPrevia);
        panelVistaPrevia.add(scrollVistaPrevia, BorderLayout.CENTER);

        splitPane.setLeftComponent(panelIzquierdo);
        splitPane.setRightComponent(panelVistaPrevia);
        splitPane.setDividerLocation(500);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnVistaPrevia = new JButton("Actualizar Vista Previa");
        btnGenerarPDF = new JButton("Generar Reporte PDF");
        btnGenerarPDF.setEnabled(false);
        panelBotones.add(btnVistaPrevia);
        panelBotones.add(btnGenerarPDF);

        add(panelBusqueda, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        btnBuscar.addActionListener(__ -> buscarAlumnos());
        btnGenerarPDF.addActionListener(__ -> generarPDF());
        btnVistaPrevia.addActionListener(__ -> actualizarVistaPrevia());

        tablaAlumnos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                boolean haySeleccion = tablaAlumnos.getSelectedRow() != -1;
                btnGenerarPDF.setEnabled(haySeleccion);
                btnVistaPrevia.setEnabled(haySeleccion);
                if (haySeleccion) {
                    actualizarVistaPrevia();
                }
            }
        });
    }

    private void buscarAlumnos() {
        String busqueda = txtBusqueda.getText().trim();
        modeloTabla.setRowCount(0);

        try {
            String sql = "SELECT a.idalumno, a.nombre, a.apellido_paterno, a.apellido_materno, " +
                        "g.grado || g.grupo as grupo, e.nombre as escuela " +
                        "FROM Alumno a " +
                        "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                        "JOIN Escuela e ON g.escuela_nombre = e.nombre " +
                        "WHERE a.id_grupo = ? AND " +
                        "(LOWER(a.nombre) LIKE LOWER(?) OR " +
                        "LOWER(a.apellido_paterno) LIKE LOWER(?) OR " +
                        "LOWER(a.apellido_materno) LIKE LOWER(?) OR " +
                        "CAST(a.idalumno AS TEXT) = ?)";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            String searchTerm = "%" + busqueda + "%";
            pstmt.setInt(1, idGrupoActual);
            pstmt.setString(2, searchTerm);
            pstmt.setString(3, searchTerm);
            pstmt.setString(4, searchTerm);
            pstmt.setString(5, busqueda);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("idalumno"));
                row.add(rs.getString("nombre"));
                row.add(rs.getString("apellido_paterno"));
                row.add(rs.getString("apellido_materno"));
                row.add(rs.getString("grupo"));
                row.add(rs.getString("escuela"));
                modeloTabla.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar: " + e.getMessage());
        }
    }

    private void cargarAlumnosDelGrupo() {
        modeloTabla.setRowCount(0);
        try {
            String sql = "SELECT a.idalumno, a.nombre, a.apellido_paterno, a.apellido_materno, " +
                        "g.grado || g.grupo as grupo, e.nombre as escuela " +
                        "FROM Alumno a " +
                        "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                        "JOIN Escuela e ON g.escuela_nombre = e.nombre " +
                        "WHERE a.id_grupo = ? " +
                        "ORDER BY a.apellido_paterno, a.apellido_materno, a.nombre";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idGrupoActual);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("idalumno"));
                row.add(rs.getString("nombre"));
                row.add(rs.getString("apellido_paterno"));
                row.add(rs.getString("apellido_materno"));
                row.add(rs.getString("grupo"));
                row.add(rs.getString("escuela"));
                modeloTabla.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar alumnos: " + e.getMessage());
        }
    }

    private void actualizarVistaPrevia() {
        int row = tablaAlumnos.getSelectedRow();
        if (row == -1) return;

        int idAlumno = (int) tablaAlumnos.getValueAt(row, 0);
        StringBuilder preview = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        try {
            // Información básica del alumno y escuela
            String sqlInfo = "SELECT a.nombre, a.apellido_paterno, a.apellido_materno, " +
                           "e.nombre as escuela, e.tipoescuela, g.nombremateria " +
                           "FROM Alumno a " +
                           "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                           "JOIN Escuela e ON g.escuela_nombre = e.nombre " +
                           "WHERE a.idalumno = ?";

            PreparedStatement pstmtInfo = conn.prepareStatement(sqlInfo);
            pstmtInfo.setInt(1, idAlumno);
            ResultSet rsInfo = pstmtInfo.executeQuery();

            if (rsInfo.next()) {
                String nombreEscuela = rsInfo.getString("escuela");
                String tipoEscuela = rsInfo.getString("tipoescuela");
                String nombreMateria = tipoEscuela.equalsIgnoreCase("primaria") ? 
                                     "Materias varias" : rsInfo.getString("nombremateria");
                String nombreCompleto = rsInfo.getString("nombre") + " " +
                                      rsInfo.getString("apellido_paterno") + " " +
                                      rsInfo.getString("apellido_materno");

                preview.append("REPORTE DE DESEMPEÑO ACADÉMICO\n");
                preview.append("==============================\n\n");
                preview.append("Escuela: ").append(nombreEscuela).append("\n");
                preview.append("Materia: ").append(nombreMateria).append("\n");
                preview.append("Alumno: ").append(nombreCompleto).append("\n\n");

                // Actividades y calificaciones
                String sqlAct = "SELECT a.nombreactividad, g.nombremateria, e.calificacion " +
                              "FROM Evaluacion e " +
                              "JOIN Actividad a ON e.idactividad = a.idactividad " +
                              "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                              "WHERE e.idalumno = ? " +
                              "ORDER BY a.fecha";

                PreparedStatement pstmtAct = conn.prepareStatement(sqlAct);
                pstmtAct.setInt(1, idAlumno);
                ResultSet rsAct = pstmtAct.executeQuery();

                preview.append("CALIFICACIONES\n");
                preview.append("-------------\n");
                double sumaCalif = 0;
                int conteoCalif = 0;

                while (rsAct.next()) {
                    String actividad = rsAct.getString("nombreactividad");
                    if (tipoEscuela.equalsIgnoreCase("primaria")) {
                        actividad += " - " + rsAct.getString("nombremateria");
                    }
                    int calificacion = rsAct.getInt("calificacion");
                    preview.append(actividad).append(": ").append(calificacion).append("\n");
                    sumaCalif += calificacion;
                    conteoCalif++;
                }

                double promedio = conteoCalif > 0 ? sumaCalif / conteoCalif : 0;
                preview.append("\nPromedio: ").append(String.format("%.1f", promedio)).append("\n\n");

                // Asistencias
                String sqlAsist = "SELECT f.fecha, a.asistencia " +
                                "FROM Asistencia a " +
                                "JOIN Fechas_asistencia f ON a.idfecha = f.idfecha " +
                                "WHERE a.idalumno = ? " +
                                "ORDER BY f.fecha";

                PreparedStatement pstmtAsist = conn.prepareStatement(sqlAsist);
                pstmtAsist.setInt(1, idAlumno);
                ResultSet rsAsist = pstmtAsist.executeQuery();

                preview.append("ASISTENCIAS\n");
                preview.append("-----------\n");
                int totalClases = 0;
                int asistencias = 0;

                while (rsAsist.next()) {
                    String fecha = sdf.format(rsAsist.getDate("fecha"));
                    boolean presente = rsAsist.getInt("asistencia") == 1;
                    preview.append(fecha).append(" - ").append(presente ? "Presente" : "No presente").append("\n");
                    totalClases++;
                    if (presente) asistencias++;
                }

                double porcentajeAsistencia = totalClases > 0 ? (asistencias * 100.0 / totalClases) : 0;
                preview.append("\nPorcentaje de asistencia: ").append(String.format("%.1f%%", porcentajeAsistencia)).append("\n\n");

                // Estado final
                preview.append("ESTADO ACADÉMICO\n");
                preview.append("----------------\n");
                String estado;
                if (promedio < 6.0 || (promedio < 7.0 && porcentajeAsistencia < 70)) {
                    estado = "Reprobado";
                } else if (promedio < 8.0 || porcentajeAsistencia < 80) {
                    estado = "Peligro de reprobar";
                } else {
                    estado = "Aprobado";
                }
                preview.append("Estado del alumno: ").append(estado);
            }

            txtVistaPrevia.setText(preview.toString());

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al generar vista previa: " + e.getMessage());
        }
    }

    private void generarPDF() {
        int row = tablaAlumnos.getSelectedRow();
        if (row == -1) return;

        int idAlumno = (int) tablaAlumnos.getValueAt(row, 0);
        String nombreCompleto = tablaAlumnos.getValueAt(row, 1) + " " +
                              tablaAlumnos.getValueAt(row, 2) + " " +
                              tablaAlumnos.getValueAt(row, 3);

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Reporte PDF");
        fileChooser.setSelectedFile(new java.io.File(nombreCompleto + "_reporte.pdf"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Document document = new Document(PageSize.A4);
                PdfWriter.getInstance(document, new FileOutputStream(fileChooser.getSelectedFile()));
                document.open();

                Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.DARK_GRAY);
                Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.DARK_GRAY);
                Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);

                // Título
                Paragraph title = new Paragraph("Reporte de desempeño Académico", titleFont);
                title.setAlignment(Element.ALIGN_CENTER);
                document.add(title);
                document.add(Chunk.NEWLINE);

                // Información del alumno y escuela
                String sqlInfo = "SELECT a.nombre, a.apellido_paterno, a.apellido_materno, " +
                               "e.nombre as escuela, e.tipoescuela, g.nombremateria " +
                               "FROM Alumno a " +
                               "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                               "JOIN Escuela e ON g.escuela_nombre = e.nombre " +
                               "WHERE a.idalumno = ?";

                PreparedStatement pstmtInfo = conn.prepareStatement(sqlInfo);
                pstmtInfo.setInt(1, idAlumno);
                ResultSet rsInfo = pstmtInfo.executeQuery();

                if (rsInfo.next()) {
                    String nombreEscuela = rsInfo.getString("escuela");
                    String tipoEscuela = rsInfo.getString("tipoescuela");
                    String nombreMateria = tipoEscuela.equalsIgnoreCase("primaria") ? 
                                         "Materias varias" : rsInfo.getString("nombremateria");

                    document.add(new Paragraph("Escuela: " + nombreEscuela, normalFont));
                    document.add(new Paragraph("Materia: " + nombreMateria, normalFont));
                    document.add(new Paragraph("Alumno: " + nombreCompleto, normalFont));
                    document.add(Chunk.NEWLINE);

                    // Calificaciones
                    document.add(new Paragraph("Calificaciones", headerFont));
                    PdfPTable tablaCalif = new PdfPTable(2);
                    tablaCalif.setWidthPercentage(100);

                    PdfPCell headerCell = new PdfPCell(new Paragraph("Actividad", headerFont));
                    headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    tablaCalif.addCell(headerCell);

                    headerCell = new PdfPCell(new Paragraph("Calificación", headerFont));
                    headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    tablaCalif.addCell(headerCell);

                    String sqlAct = "SELECT a.nombreactividad, g.nombremateria, e.calificacion " +
                                  "FROM Evaluacion e " +
                                  "JOIN Actividad a ON e.idactividad = a.idactividad " +
                                  "JOIN Grupo g ON a.id_grupo = g.idgrupo " +
                                  "WHERE e.idalumno = ? " +
                                  "ORDER BY a.fecha";

                    PreparedStatement pstmtAct = conn.prepareStatement(sqlAct);
                    pstmtAct.setInt(1, idAlumno);
                    ResultSet rsAct = pstmtAct.executeQuery();

                    double sumaCalif = 0;
                    int conteoCalif = 0;

                    while (rsAct.next()) {
                        String actividad = rsAct.getString("nombreactividad");
                        if (tipoEscuela.equalsIgnoreCase("primaria")) {
                            actividad += " - " + rsAct.getString("nombremateria");
                        }
                        int calificacion = rsAct.getInt("calificacion");

                        tablaCalif.addCell(new Paragraph(actividad, normalFont));
                        tablaCalif.addCell(new Paragraph(String.valueOf(calificacion), normalFont));

                        sumaCalif += calificacion;
                        conteoCalif++;
                    }

                    double promedio = conteoCalif > 0 ? sumaCalif / conteoCalif : 0;

                    PdfPCell promedioCell = new PdfPCell(new Paragraph("Promedio", headerFont));
                    promedioCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    tablaCalif.addCell(promedioCell);
                    tablaCalif.addCell(new Paragraph(String.format("%.1f", promedio), headerFont));

                    document.add(tablaCalif);
                    document.add(Chunk.NEWLINE);

                    // Asistencias
                    document.add(new Paragraph("Historial de Asistencias", headerFont));
                    PdfPTable tablaAsist = new PdfPTable(2);
                    tablaAsist.setWidthPercentage(100);

                    headerCell = new PdfPCell(new Paragraph("Fecha", headerFont));
                    headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    tablaAsist.addCell(headerCell);

                    headerCell = new PdfPCell(new Paragraph("Estado", headerFont));
                    headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    tablaAsist.addCell(headerCell);

                    String sqlAsist = "SELECT f.fecha, a.asistencia " +
                                    "FROM Asistencia a " +
                                    "JOIN Fechas_asistencia f ON a.idfecha = f.idfecha " +
                                    "WHERE a.idalumno = ? " +
                                    "ORDER BY f.fecha";

                    PreparedStatement pstmtAsist = conn.prepareStatement(sqlAsist);
                    pstmtAsist.setInt(1, idAlumno);
                    ResultSet rsAsist = pstmtAsist.executeQuery();

                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    int totalClases = 0;
                    int asistencias = 0;

                    while (rsAsist.next()) {
                        String fecha = sdf.format(rsAsist.getDate("fecha"));
                        boolean presente = rsAsist.getInt("asistencia") == 1;

                        tablaAsist.addCell(new Paragraph(fecha, normalFont));
                        tablaAsist.addCell(new Paragraph(presente ? "Presente" : "No presente", normalFont));

                        totalClases++;
                        if (presente) asistencias++;
                    }

                    document.add(tablaAsist);
                    document.add(Chunk.NEWLINE);

                    double porcentajeAsistencia = totalClases > 0 ? (asistencias * 100.0 / totalClases) : 0;
                    document.add(new Paragraph(
                        String.format("Porcentaje de asistencia: %.1f%%", porcentajeAsistencia),
                        headerFont
                    ));
                    document.add(Chunk.NEWLINE);

                    // Estado final
                    String estado;
                    BaseColor colorEstado;
                    if (promedio < 6.0 || (promedio < 7.0 && porcentajeAsistencia < 70)) {
                        estado = "Estado del alumno: Reprobado";
                        colorEstado = BaseColor.RED;
                    } else if (promedio < 8.0 || porcentajeAsistencia < 80) {
                        estado = "Estado del alumno: Peligro de reprobar";
                        colorEstado = BaseColor.ORANGE;
                    } else {
                        estado = "Estado del alumno: Aprobado";
                        colorEstado = BaseColor.GREEN;
                    }

                    Font estadoFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, colorEstado);
                    Paragraph estadoParrafo = new Paragraph(estado, estadoFont);
                    estadoParrafo.setAlignment(Element.ALIGN_CENTER);
                    document.add(estadoParrafo);
                }

                document.close();
                JOptionPane.showMessageDialog(this, "Reporte PDF generado exitosamente");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al generar PDF: " + e.getMessage());
            }
        }
    }

    public static void main(String args[]) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> {
            new ModuloPDF(1).setVisible(true); // Cambiar el ID del grupo según sea necesario
        });
    }
}